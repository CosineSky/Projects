/*************************************
* @author: CosineSky
* @date: 2022/11/24
* @version: 0.3
**************************************/

#include <stdio.h>
#include <stdbool.h>
#include <windows.h>

#define MAX_HEIGHT 24
#define MAX_WIDTH 24
#define CB chessboard->board
#define red_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
#define gray_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
#define aqua_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 11);
#define green_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
#define white_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);

enum CHESS_COLOR { BLANK, RED, YELLOW };
// BLANK = 0, RED = 1, YELLOW = 2

typedef struct _chessboard {
    int width, height;
    int board[MAX_HEIGHT][MAX_WIDTH];
    int colSize[MAX_WIDTH];
    int delta;
} Chessboard; Chessboard HL;

void InitBoard(Chessboard* chessboard, int width, int height) {
    chessboard->width = width;
    chessboard->height = height;
    memset(chessboard->board, 0, sizeof(chessboard->board));
    memset(chessboard->colSize, 0, sizeof(chessboard->colSize));
    chessboard->delta = 0;
}

void PutChess(Chessboard* chessboard, int column, int color) {
    // Clear Highlights
    for ( int i=1; i<=HL.height; i++ ) {
        for ( int j=1; j<=HL.width; j++ ) {
            HL.board[i][j] = 0;
        }
    }
    // Illegal postion
    if (column < 1 || column > chessboard->width) { return; }
    if (chessboard->colSize[column] >= chessboard->height) { return; }
    if (color == RED && chessboard->delta == 1) { return; }
    if (color == YELLOW && chessboard->delta == 0) { return; }
    // Put chess
    chessboard->colSize[column]++;
    chessboard->board[chessboard->height - chessboard->colSize[column] + 1][column] = color;
    HL.board[chessboard->height - chessboard->colSize[column] + 1][column] = 1;
    if (color == RED) chessboard->delta++;
    if (color == YELLOW) chessboard->delta--;
}

int GetChess(Chessboard* chessboard, int x, int y) {
    if (x < 1 || x > chessboard->height) return -1;
    if (y < 1 || y > chessboard->width) return -1;
    return chessboard->board[x][y];
}

void Draw(Chessboard* chessboard, int pos) {
    int n = chessboard->height;
    int m = chessboard->width;
    system("cls");
    aqua_ printf("\n>> CosSky's Four in a Row v0.3 <<");
    white_ printf("\n==============================================\n\n");
    aqua_ printf("Message Box:\n");
    white_ printf(">> The AI put a chess piece on column %d.\n\n", pos);
    for (int i = 1; i <= n; i++) {
        gray_ printf(" |");
        for (int j = 1; j <= m; j++) {
            switch (chessboard->board[i][j]) {
                case BLANK: { gray_ printf(" |") ;break; }
                case RED:
                    if ( HL.board[i][j] ) { white_ printf("X"); gray_ printf("|"); }
                    else { red_ printf("X"); gray_ printf("|"); }
                    break;
                case YELLOW:
                    green_ printf("O"); gray_ printf("|");
                    break;
            }
        }
        white_ printf("\n");
    }
    printf(" ");
    for ( int i=1; i<=m; i++ ) { printf(" %d", i%10); }
    printf("\n\nInput any column number to put a chess piece.\n");
    printf(">> Your choice: ");
}

int GetColor_mtw(Chessboard* chessboard) {
    int h = chessboard->height, w = chessboard->width;
    int cur_red = 0, cur_yellow = 0, next_color;
    for ( int i=1; i<=h; i++ ) {
        for ( int j=1; j<=w; j++ ) {
            switch ( GetChess((chessboard), i, j) ) {
                case RED: { cur_red++; break; }
                case YELLOW: { cur_yellow++; break; }
            }
        }
    }
    return cur_red==cur_yellow ? RED:YELLOW;
}

bool IsFinished_mtw(Chessboard* chessboard) {
    int h = chessboard->height, w = chessboard->width;
    for ( int color=1; color<=2; color++ ) {
        for ( int x=1; x<=w; x++ ) {
            for ( int y=1; y<=h; y++ ) {
                if ( ((x>=4) && (chessboard->board[y][x]==color && chessboard->board[y][x-1]==color && chessboard->board[y][x-2]==color && chessboard->board[y][x-3]==color)) ||
                    ((y>=4) && (chessboard->board[y][x]==color && chessboard->board[y-1][x]==color && chessboard->board[y-2][x]==color && chessboard->board[y-3][x]==color)) ||
                    ((x<=w-3) && (chessboard->board[y][x]==color && chessboard->board[y][x+1]==color && chessboard->board[y][x+2]==color && chessboard->board[y][x+3]==color)) ||
                    ((y<=h-3) && (chessboard->board[y][x]==color && chessboard->board[y+1][x]==color && chessboard->board[y+2][x]==color && chessboard->board[y+3][x]==color)) ||
                    ((x>=4 && y>=4) && (chessboard->board[y][x]==color && chessboard->board[y-1][x-1]==color && chessboard->board[y-2][x-2]==color && chessboard->board[y-3][x-3]==color)) ||
                    ((x<=w-3 && y>= 4) &&(chessboard->board[y][x]==color && chessboard->board[y-1][x+1]==color && chessboard->board[y-2][x+2]==color && chessboard->board[y-3][x+3]==color)) ||
                    ((x>=4 && y<=h-3) && (chessboard->board[y][x]==color && chessboard->board[y+1][x-1]==color && chessboard->board[y+2][x-2]==color && chessboard->board[y+3][x-3]==color)) ||
                    ((x<=w-3 && y<=h-3) && (chessboard->board[y][x]==color && chessboard->board[y+1][x+1]==color && chessboard->board[y+2][x+2]==color && chessboard->board[y+3][x+3]==color))
                ) { return 1; }
            }
        }
    }
    return 0;
}
bool JudgeLine_mtw(int X, int Y, int c, int h, int w, int arr[MAX_HEIGHT][MAX_WIDTH]) {
    if ( arr[Y][X] != 0 ) { return 0; }
    if ( ((Y<=h-3) && (arr[Y+1][X]==c && arr[Y+2][X]==c && arr[Y+3][X]==c)) ||
        ((X>=4) && (arr[Y][X-1]==c && arr[Y][X-2]==c && arr[Y][X-3]==c)) ||
        ((X>=3 && X<=w-1) && (arr[Y][X-2]==c && arr[Y][X-1]==c && arr[Y][X+1]==c)) ||
        ((X>=2 && X<=w-2) && (arr[Y][X-1]==c && arr[Y][X+1]==c && arr[Y][X+2]==c)) ||
        ((X<=w-3) && (arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==c)) ||
        ((X>=4 && Y<=h-3) && (arr[Y+1][X-1]==c && arr[Y+2][X-2]==c && arr[Y+3][X-3]==c)) ||
        ((X>=4 && Y>=4) && (arr[Y-1][X-1]==c && arr[Y-2][X-2]==c && arr[Y-3][X-3]==c)) ||
        ((X<=w-3 && Y<=h-3) && (arr[Y+1][X+1]==c && arr[Y+2][X+2]==c && arr[Y+3][X+3]==c)) ||
        ((X<=w-3 && Y>=4) && (arr[Y-1][X+1]==c && arr[Y-2][X+2]==c && arr[Y-3][X+3]==c)) ||
        ((X>=3 && X<=w-1 && Y<=h-2 && Y>=2) && (arr[Y+2][X-2]==c && arr[Y+1][X-1]==c && arr[Y-1][X+1]==c)) ||
        ((X>=2 && X<=w-2 && Y<=h-1 && Y>=3) && (arr[Y+1][X-1]==c && arr[Y-1][X+1]==c && arr[Y-2][X+2]==c)) ||
        ((X>=3 && X<=w-1 && Y<=h-1 && Y>=3) && (arr[Y-2][X-2]==c && arr[Y-1][X-1]==c && arr[Y+1][X+1]==c)) ||
        ((X>=2 && X<=w-2 && Y<=h-2 && Y>=2) && (arr[Y-1][X-1]==c && arr[Y+1][X+1]==c && arr[Y+2][X+2]==c))
    ) { return 1; }
    return 0;
}
bool JudgeL3_mtw(int X, int Y, int c, int h, int w, int arr[MAX_HEIGHT][MAX_WIDTH]) {
    if ( arr[Y][X] != 0 ) { return 0; }
    if ( ((Y==h && X>=4 && X<=w-1) && (arr[Y][X-1]==c && arr[Y][X-2]==c && arr[Y][X-3]==0 && arr[Y][X+1]==0)) ||
        ((Y==h && X>=3 && X<=w-2) && (arr[Y][X-1]==c && arr[Y][X-2]==0 && arr[Y][X+1]==c && arr[Y][X+2]==0)) ||
        ((Y==h && X>=2 && X<=w-3) && (arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==0 && arr[Y][X-1]==0)) ||
        ((Y<=h-1 && X>=4 && X<=w-1) && (arr[Y][X-1]==c && arr[Y][X-2]==c && arr[Y][X-3]==0 && arr[Y][X+1]==0 && arr[Y+1][X-3]!=0 && arr[Y+1][X+1]!=0)) ||
        ((Y<=h-1 && X<=w-3 && X>=2) && (arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==0 && arr[Y][X-1]==0 && arr[Y+1][X+3]!=0 && arr[Y+1][X-1]!=0)) ||
        ((Y<=h-1 && X>=3 && X<=w-2) && (arr[Y][X-1]==c && arr[Y][X-2]==0 && arr[Y][X+1]==c && arr[Y][X+2]==0 && arr[Y+1][X-2]!=0 && arr[Y+1][X+2]!=0)) ||
        ((Y==h-3 && Y>=2 && X>=2 && X<=w-3) && (arr[Y+1][X+1]==c && arr[Y+2][X+2]==c && arr[Y+3][X+3]==0 && arr[Y-1][X-1]==0 && arr[Y][X-1]!=0)) ||
        ((Y<=h-4 && Y>=2 && X>=2 && X<=w-3) && (arr[Y+1][X+1]==c && arr[Y+2][X+2]==c && arr[Y+3][X+3]==0 && arr[Y-1][X-1]==0 && arr[Y][X-1]!=0 && arr[Y+4][X+3]!=0)) ||
        ((Y==h-2 && Y>=3 && X>=3 && X<=w-2) && (arr[Y+1][X+1]==c && arr[Y-1][X-1]==c && arr[Y+2][X+2]==0 && arr[Y-2][X-2]==0 && arr[Y-1][X-2]!=0)) ||
        ((Y<=h-3 && Y>=3 && X>=3 && X<=w-2) && (arr[Y+1][X+1]==c && arr[Y-1][X-1]==c && arr[Y+2][X+2]==0 && arr[Y-2][X-2]==0 && arr[Y-1][X-2]!=0 && arr[Y+3][X+2]!=0)) ||
        ((Y==h-1 && Y>=4 && X>=4 && X<=w-1) && (arr[Y-1][X-1]==c && arr[Y-2][X-2]==c && arr[Y+1][X+1]==0 && arr[Y-3][X-3]==0 && arr[Y-2][X-3]!=0)) ||
        ((Y<=h-2 && Y>=4 && X>=4 && X<=w-1) && (arr[Y-1][X-1]==c && arr[Y-2][X-2]==c && arr[Y+1][X+1]==0 && arr[Y-3][X-3]==0 && arr[Y-2][X-3]!=0 && arr[Y+2][X+1]!=0)) ||
        ((Y==h-3 && Y>=2 && X>=4 && X<=w-1) && (arr[Y+1][X-1]==c && arr[Y+2][X-2]==c && arr[Y+3][X-3]==0 && arr[Y-1][X+1]==0 && arr[Y][X+1]!=0)) ||
        ((Y<=h-4 && Y>=2 && X>=4 && X<=w-1) && (arr[Y+1][X-1]==c && arr[Y+2][X-2]==c && arr[Y+3][X-3]==0 && arr[Y-1][X+1]==0 && arr[Y][X+1]!=0 && arr[Y+4][X-3]!=0)) ||
        ((Y==h-2 && Y>=3 && X>=3 && X<=w-2) && (arr[Y+1][X-1]==c && arr[Y-1][X+1]==c && arr[Y+2][X-2]==0 && arr[Y-2][X+2]==0 && arr[Y-1][X+2]!=0)) ||
        ((Y<=h-3 && Y>=3 && X>=3 && X<=w-2) && (arr[Y+1][X-1]==c && arr[Y-1][X+1]==c && arr[Y+2][X-2]==0 && arr[Y-2][X+2]==0 && arr[Y-1][X+2]!=0 && arr[Y+3][X-2]!=0)) ||
        ((Y==h-1 && Y>=4 && X>=2 && X<=w-3) && (arr[Y-1][X+1]==c && arr[Y-2][X+2]==c && arr[Y+1][X-1]==0 && arr[Y-3][X+3]==0 && arr[Y-2][X+3]!=0)) ||
        ((Y<=h-2 && Y>=4 && X>=2 && X<=w-3) && (arr[Y-1][X+1]==c && arr[Y-2][X+2]==c && arr[Y+1][X-1]==0 && arr[Y-3][X+3]==0 && arr[Y-2][X+3]!=0 && arr[Y+2][X-1]!=0))
    ) { return 1; }
    return 0;
}
int CountD3_mtw(int X, int Y, int c, int h, int w, int arr[MAX_HEIGHT][MAX_WIDTH]) {
    if ( arr[Y][X] != 0 ) { return 0; }
    int D3 = 0;
    if ((Y==h-2) && (arr[Y+1][X]==c && arr[Y+2][X]==c)) { D3++; }
    if ((Y<=h-3) && (arr[Y+1][X]==c && arr[Y+2][X]==c && arr[Y+3][X]==3-c)) { D3++; }
    if((Y==h && X>=4 && X<=w-1) && (arr[Y][X-3]==3-c && arr[Y][X-2]==c && arr[Y][X-1]==c && arr[Y][X+1]==0)) { D3++; }
    if((Y==h && X>=3 && X<=w-2) && (arr[Y][X-2]==3-c && arr[Y][X-1]==c && arr[Y][X+1]==c && arr[Y][X+2]==0)) { D3++; }
    if((Y==h && X>=2 && X<=w-3) && (arr[Y][X-1]==3-c && arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==0)) { D3++; }
    if((Y==h && X>=4 && X<=w-1) && (arr[Y][X-3]==0 && arr[Y][X-2]==c && arr[Y][X-1]==c && arr[Y][X+1]==3-c)) { D3++; }
    if((Y==h && X>=3 && X<=w-2) && (arr[Y][X-2]==0 && arr[Y][X-1]==c && arr[Y][X+1]==c && arr[Y][X+2]==3-c)) { D3++; }
    if((Y==h && X>=2 && X<=w-3) && (arr[Y][X-1]==0 && arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==3-c)) { D3++; }
    if((Y<=h-1 && X>=4 && X<=w-1) && (arr[Y][X-3]==3-c && arr[Y][X-2]==c && arr[Y][X-1]==c && arr[Y][X+1]==0 && arr[Y+1][X+1]!=0)) { D3++; }
    if((Y<=h-1 && X>=3 && X<=w-2) && (arr[Y][X-2]==3-c && arr[Y][X-1]==c && arr[Y][X+1]==c && arr[Y][X+2]==0 && arr[Y+1][X+2]!=0)) { D3++; }
    if((Y<=h-1 && X>=2 && X<=w-3) && (arr[Y][X-1]==3-c && arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==0 && arr[Y+1][X+3]!=0)) { D3++; }
    if((Y<=h-1 && X>=4 && X<=w-1) && (arr[Y][X-3]==0 && arr[Y][X-2]==c && arr[Y][X-1]==c && arr[Y][X+1]==3-c && arr[Y+1][X-3]!=0)) { D3++; }
    if((Y<=h-1 && X>=3 && X<=w-2) && (arr[Y][X-2]==0 && arr[Y][X-1]==c && arr[Y][X+1]==c && arr[Y][X+2]==3-c && arr[Y+1][X-2]!=0)) { D3++; }
    if((Y<=h-1 && X>=2 && X<=w-3) && (arr[Y][X-1]==0 && arr[Y][X+1]==c && arr[Y][X+2]==c && arr[Y][X+3]==3-c && arr[Y+1][X-1]!=0)) { D3++; }
    if((Y==h-1 && Y>=4 && X>=4 && X<=w-1) && (arr[Y-3][X-3]==3-c && arr[Y-2][X-2]==c && arr[Y-1][X-1]==c && arr[Y+1][X+1]==0)) { D3++; }
    if((Y==h-2 && Y>=3 && X>=3 && X<=w-2) && (arr[Y-2][X-2]==3-c && arr[Y-1][X-1]==c && arr[Y+1][X+1]==c && arr[Y+2][X+2]==0)) { D3++; }
    if((Y==h-3 && Y>=2 && X>=2 && X<=w-3) && (arr[Y-1][X-1]==3-c && arr[Y+1][X+1]==c && arr[Y+2][X+2]==c && arr[Y+3][X+3]==0)) { D3++; }
    if((Y<=h-2 && Y>=4 && X>=4 && X<=w-1) && (arr[Y-3][X-3]==3-c && arr[Y-2][X-2]==c && arr[Y-1][X-1]==c && arr[Y+1][X+1]==0 && arr[Y+2][X+1]!=0)) { D3++; }
    if((Y<=h-3 && Y>=3 && X>=3 && X<=w-2) && (arr[Y-2][X-2]==3-c && arr[Y-1][X-1]==c && arr[Y+1][X+1]==c && arr[Y+2][X+2]==0 && arr[Y+2][X+1]!=0)) { D3++; }
    if((Y<=h-4 && Y>=2 && X>=2 && X<=w-3) && (arr[Y-1][X-1]==3-c && arr[Y+1][X+1]==c && arr[Y+2][X+2]==c && arr[Y+3][X+3]==0 && arr[Y+2][X+1]!=0)) { D3++; }
    if((Y<=h-2 && Y>=4 && X>=4 && X<=w-1) && (arr[Y-3][X-3]==0 && arr[Y-2][X-2]==c && arr[Y-1][X-1]==c && arr[Y+1][X+1]==3-c && arr[Y-2][X-3]!=0)) { D3++; }
    if((Y<=h-3 && Y>=3 && X>=3 && X<=w-2) && (arr[Y-2][X-2]==0 && arr[Y-1][X-1]==c && arr[Y+1][X+1]==c && arr[Y+2][X+2]==3-c && arr[Y-1][X-2]!=0)) { D3++; }
    if((Y<=h-4 && Y>=2 && X>=2 && X<=w-3) && (arr[Y-1][X-1]==0 && arr[Y+1][X+1]==c && arr[Y+2][X+2]==c && arr[Y+3][X+3]==3-c && arr[Y][X-1]!=0)) { D3++; }
    if((Y==h-1 && Y>=4 && X>=2 && X<=w-3) && (arr[Y-3][X+3]==3-c && arr[Y-2][X+2]==c && arr[Y-1][X+1]==c && arr[Y+1][X-1]==0)) { D3++; }
    if((Y==h-2 && Y>=3 && X>=3 && X<=w-2) && (arr[Y-2][X+2]==3-c && arr[Y-1][X+1]==c && arr[Y+1][X-1]==c && arr[Y+2][X-2]==0)) { D3++; }
    if((Y==h-3 && Y>=2 && X>=4 && X<=w-1) && (arr[Y-1][X+1]==3-c && arr[Y+1][X-1]==c && arr[Y+2][X-2]==c && arr[Y+3][X-3]==0)) { D3++; }
    if((Y<=h-2 && Y>=4 && X>=2 && X<=w-3) && (arr[Y-3][X+3]==3-c && arr[Y-2][X+2]==c && arr[Y-1][X+1]==c && arr[Y+1][X-1]==0 && arr[Y+2][X-1]!=0)) { D3++; }
    if((Y<=h-3 && Y>=3 && X>=3 && X<=w-2) && (arr[Y-2][X+2]==3-c && arr[Y-1][X+1]==c && arr[Y+1][X-1]==c && arr[Y+2][X-2]==0 && arr[Y+2][X-1]!=0)) { D3++; }
    if((Y<=h-4 && Y>=2 && X>=4 && X<=w-1) && (arr[Y-1][X+1]==3-c && arr[Y+1][X-1]==c && arr[Y+2][X-2]==c && arr[Y+3][X-3]==0 && arr[Y+2][X-1]!=0)) { D3++; }
    if((Y<=h-2 && Y>=4 && X>=2 && X<=w-3) && (arr[Y-3][X+3]==0 && arr[Y-2][X+2]==c && arr[Y-1][X+1]==c && arr[Y+1][X-1]==3-c && arr[Y-2][X+3]!=0)) { D3++; }
    if((Y<=h-3 && Y>=3 && X>=3 && X<=w-2) && (arr[Y-2][X+2]==0 && arr[Y-1][X+1]==c && arr[Y+1][X-1]==c && arr[Y+2][X-2]==3-c && arr[Y-1][X+2]!=0)) { D3++; }
    if((Y<=h-4 && Y>=2 && X>=4 && X<=w-1) && (arr[Y-1][X+1]==0 && arr[Y+1][X-1]==c && arr[Y+2][X-2]==c && arr[Y+3][X-3]==3-c && arr[Y][X+1]!=0)) { D3++; }
    if((Y==h && X>=4) && (arr[Y][X-3]==c && arr[Y][X-2]==c && arr[Y][X-1]==0)) { D3++; }
    if((Y==h && X>=4) && (arr[Y][X-3]==c && arr[Y][X-2]==0 && arr[Y][X-1]==c)) { D3++; }
    if((Y==h && X>=3 && X<=w-1) && (arr[Y][X-2]==c && arr[Y][X-1]==0 && arr[Y][X+1]==c)) { D3++; }
    if((Y==h && X>=2 && X<=w-2) && (arr[Y][X-1]==c && arr[Y][X+1]==0 && arr[Y][X+2]==c)) { D3++; }
    if((Y==h && X<=w-3) && (arr[Y][X+1]==0 && arr[Y][X+2]==c && arr[Y][X+3]==c)) { D3++; }
    if((Y==h && X<=w-3) && (arr[Y][X+1]==c && arr[Y][X+2]==0 && arr[Y][X+3]==c)) { D3++; }
    if((Y<=h-1 && X>=4) && (arr[Y][X-3]==c && arr[Y][X-2]==c && arr[Y][X-1]==0 && arr[Y+1][X-1]!=0)) { D3++; }
    if((Y<=h-1 && X>=4) && (arr[Y][X-3]==c && arr[Y][X-2]==0 && arr[Y][X-1]==c && arr[Y+1][X-2]!=0)) { D3++; }
    if((Y<=h-1 && X>=3 && X<=w-1) && (arr[Y][X-2]==c && arr[Y][X-1]==0 && arr[Y][X+1]==c && arr[Y+1][X-1]!=0)) { D3++; }
    if((Y<=h-1 && X>=2 && X<=w-2) && (arr[Y][X-1]==c && arr[Y][X+1]==0 && arr[Y][X+2]==c && arr[Y+1][X+1]!=0)) { D3++; }
    if((Y<=h-1 && X<=w-3) && (arr[Y][X+1]==0 && arr[Y][X+2]==c && arr[Y][X+3]==c && arr[Y+1][X+1]!=0)) { D3++; }
    if((Y<=h-1 && X<=w-3) && (arr[Y][X+1]==c && arr[Y][X+2]==0 && arr[Y][X+3]==c && arr[Y+1][X+2]!=0)) { D3++; }
    if((X>=4 && Y>=4) && (arr[Y-3][X-3]==c && arr[Y-2][X-2]==c && arr[Y-1][X-1]==0 && arr[Y][X-1]!=0)) { D3++; }
    if((X>=4 && Y>=4) && (arr[Y-3][X-3]==c && arr[Y-2][X-2]==0 && arr[Y-1][X-1]==c && arr[Y-1][X-2]!=0)) { D3++; }
    if((X>=3 && X<=w-1 && Y>=3 && Y<=h-1) && (arr[Y-2][X-2]==c && arr[Y-1][X-1]==0 && arr[Y][X-1]!=0 && arr[Y+1][X+1]==c)) { D3++; }
    if((X>=2 && X<=w-2 && Y>=2 && Y<=h-2) && (arr[Y-1][X-1]==c && arr[Y+1][X+1]==0 && arr[Y+2][X+1]!=0 && arr[Y+2][X+2]==c)) { D3++; }
    if((X<=w-3 && Y<=h-3) && (arr[Y+1][X+1]==0 && arr[Y+2][X+1]!=0 && arr[Y+2][X+2]==c && arr[Y+3][X+3]==c)) { D3++; }
    if((X<=w-3 && Y<=h-3) && (arr[Y+1][X+1]==c && arr[Y+2][X+2]==0 && arr[Y+3][X+2]!=0 && arr[Y+3][X+3]==c)) { D3++; }
    if((X<=w-3 && Y>=4) && (arr[Y-3][X+3]==c && arr[Y-2][X+2]==c && arr[Y-1][X+1]==0 && arr[Y][X+1]!=0)) { D3++; }
    if((X<=w-3 && Y>=4) && (arr[Y-3][X+3]==c && arr[Y-2][X+2]==0 && arr[Y-1][X+1]==c && arr[Y-1][X+2]!=0)) { D3++; }
    if((X>=2 && X<=w-2 && Y>=3 && Y<=h-1) && (arr[Y-2][X+2]==c && arr[Y-1][X+1]==0 && arr[Y][X+1]!=0 && arr[Y+1][X-1]==c)) { D3++; }
    if((X>=3 && X<=w-1 && Y>=2 && Y<=h-2) && (arr[Y-1][X+1]==c && arr[Y+1][X-1]==0 && arr[Y+2][X-1]!=0 && arr[Y+2][X-2]==c)) { D3++; }
    if((X>=4 && Y<=h-3) && (arr[Y+1][X-1]==0 && arr[Y+2][X-1]!=0 && arr[Y+2][X-2]==c && arr[Y+3][X-3]==c)) { D3++; }
    if((X>=4 && Y<=h-3) && (arr[Y+1][X-1]==c && arr[Y+2][X-2]==0 && arr[Y+3][X-2]!=0 && arr[Y+3][X-3]==c)) { D3++; }
    return D3;
}

int Player_mtw(Chessboard* chessboard) {
    /*  
        Evaluation 1 runs twice, as AI and its opponent.
        Evaluation 2 runs once, focusing on potential risks.
        k[0] = opponent and k[1] = AI.
        The existence of 'bias' gives the AI preference to attack.
        For each different situation, 'bias' is given a unique coefficient.

        SCORE LIST: ( Offensive / Defensive )
        =============================================
        Single L4:              +6000   /   +1000
        Instant Double D4:      +700    /   +500
        Single L3:              +300    /   +200
        Multiple D3:            +300    /   +200
        Potential Double D4:    +60     /   +50
        Trap:                   +50     /   +50
        Upside-down V shape:    +15     /   +12
        Single D3:              +5      /   +4
        Random pieces:          +pce    /   +pce
        =============================================
        Giving L4:              -800    /   -800
        Giving L3:              -150    /   -150
        Giving Multiple D3:     -150    /   -150
        =============================================
    */
    int h = chessboard->height, w = chessboard->width;
    int ME = GetColor_mtw(chessboard), OPPO = 3 - ME;
    int k[2] = {OPPO, ME}, score[MAX_WIDTH][2] = {0};
    int NewBoard[MAX_HEIGHT][MAX_WIDTH] = {0};

    /* Eva 1: the current step. */
    for ( int m = 0; m <= 1; m++ ) {
        for ( int i = 1; i <= w; i++ ) {
            int bias = m, trap = -1;
            if ( m && trap != -1 ) { score[i][m] += 20; } 
            int x = i, y = chessboard->height - chessboard->colSize[i];

            // Update the copied board.
            for ( int y=1; y<=h; y++ ) {
                for ( int x=1; x<=w; x++ ) {
                    NewBoard[y][x] = chessboard->board[y][x];
                }
            }
            // Skip any illegal column.
            if ( y <= 0 ) { score[i][m] =- 10000; continue; }

            // SINGLE 4.
            if ( JudgeLine_mtw(x, y, k[m], h, w, NewBoard) ) { score[i][m] += (1000 + 5000 * bias); }
            // SINGLE L3.
            if ( JudgeL3_mtw(x, y, k[m], h, w, NewBoard) ) { score[i][m] += (200 + 100 * bias); }
            // MULTIPLE D3's
            int count = CountD3_mtw(x, y, k[m], h, w, NewBoard);
            if ( count == 1 ) { score[i][m] += (4 + bias); } 
            else if ( count >= 2 ) { score[i][m] += (200 + 100 * bias); }

            // POTENTIAL BACK-TO-BACK D4 ( Current & Following steps. )
            NewBoard[y][x] = k[m];
            if ( ((x>=2 && y>=2) && (y==h || (y<=h-1 && NewBoard[y+1][x-1]!=0)) && (JudgeLine_mtw(x-1, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x-1, y-1, k[m], h, w, NewBoard))) ||
                ((x>=3 && y>=2) && (y==h || (y<=h-1 && NewBoard[y+1][x-2]!=0)) && (JudgeLine_mtw(x-2, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x-2, y-1, k[m], h, w, NewBoard))) ||
                ((x>=4 && y>=2) && (y==h || (y<=h-1 && NewBoard[y+1][x-3]!=0)) && (JudgeLine_mtw(x-3, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x-3, y-1, k[m], h, w, NewBoard))) ||
                ((x<=w-1 && y>=2) && (y==h || (y<=h-1 && NewBoard[y+1][x+1]!=0)) && (JudgeLine_mtw(x+1, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x+1, y-1, k[m], h, w, NewBoard))) ||
                ((x<=w-2 && y>=2) && (y==h || (y<=h-1 && NewBoard[y+1][x+2]!=0)) && (JudgeLine_mtw(x+2, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x+2, y-1, k[m], h, w, NewBoard))) ||
                ((x<=w-3 && y>=2) && (y==h || (y<=h-1 && NewBoard[y+1][x+3]!=0)) && (JudgeLine_mtw(x+3, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x+3, y-1, k[m], h, w, NewBoard)))
            ) { score[i][m] += (500 + 200 * bias); }
            if ( ((x>=2 && y>=2 && y<=h-1) && (NewBoard[y+1][x-1]==0 && JudgeLine_mtw(x-1, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x-1, y-1, k[m], h, w, NewBoard))) ||
                ((x>=3 && y>=2 && y<=h-1) && (NewBoard[y+1][x-2]==0 && JudgeLine_mtw(x-2, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x-2, y-1, k[m], h, w, NewBoard))) ||
                ((x>=4 && y>=2 && y<=h-1) && (NewBoard[y+1][x-3]==0 && JudgeLine_mtw(x-3, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x-3, y-1, k[m], h, w, NewBoard))) ||
                ((x<=w-1 && y>=2 && y<=h-1) && (NewBoard[y+1][x+1]==0 && JudgeLine_mtw(x+1, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x+1, y-1, k[m], h, w, NewBoard))) ||
                ((x<=w-2 && y>=2 && y<=h-1) && (NewBoard[y+1][x+2]==0 && JudgeLine_mtw(x+2, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x+2, y-1, k[m], h, w, NewBoard))) ||
                ((x<=w-3 && y>=2 && y<=h-1) && (NewBoard[y+1][x+3]==0 && JudgeLine_mtw(x+3, y, k[m], h, w, NewBoard) && JudgeLine_mtw(x+3, y-1, k[m], h, w, NewBoard)))
            ) { 
                score[i][m] += (50 + 10 * bias);
                if ( m == 1 ) { trap = i; }
            }
            NewBoard[y][x] = 0;

            // SINGLE F3. ( Horizontal & Inclined )
            if ( ((x>=4 && x<=w-1) && (chessboard->board[y][x-2]==k[m] && chessboard->board[y][x-1]==k[m] && chessboard->board[y][x-3]==0 && chessboard->board[y][x+1]==0)) ||
                ((x>=3 && x<=w-2) && (chessboard->board[y][x-1]==k[m] && chessboard->board[y][x+1]==k[m] && chessboard->board[y][x-2]==0 && chessboard->board[y][x+2]==0)) ||
                ((x>=2 && x<=w-3) && (chessboard->board[y][x+1]==k[m] && chessboard->board[y][x+2]==k[m] && chessboard->board[y][x+3]==0 && chessboard->board[y][x-1]==0)) ||
                ((x>=4 && x<=w-1 && y>=4 && y<=h-1) && (chessboard->board[y-2][x-2]==k[m] && chessboard->board[y-1][x-1]==k[m] && chessboard->board[y-3][x-3]==0 && chessboard->board[y+1][x+1]==0)) ||
                ((x>=3 && x<=w-2 && y>=3 && y<=h-2) && (chessboard->board[y-1][x-1]==k[m] && chessboard->board[y+1][x+1]==k[m] && chessboard->board[y-2][x-2]==0 && chessboard->board[y+2][x+2]==0)) ||
                ((x>=2 && x<=w-3 && y>=2 && y<=h-3) && (chessboard->board[y+1][x+1]==k[m] && chessboard->board[y+2][x+2]==k[m] && chessboard->board[y+3][x+3]==0 && chessboard->board[y-1][x-1]==0)) ||
                ((x>=2 && x<=w-3 && y>=4 && y<=h-1) && (chessboard->board[y-2][x+2]==k[m] && chessboard->board[y-1][x+1]==k[m] && chessboard->board[y-3][x+3]==0 && chessboard->board[y+1][x-1]==0)) ||
                ((x>=3 && x<=w-2 && y>=3 && y<=h-2) && (chessboard->board[y-1][x+1]==k[m] && chessboard->board[y+1][x-1]==k[m] && chessboard->board[y-2][x+2]==0 && chessboard->board[y+2][x-2]==0)) ||
                ((x>=4 && x<=w-1 && y>=2 && y<=h-3) && (chessboard->board[y+1][x-1]==k[m] && chessboard->board[y+2][x-2]==k[m] && chessboard->board[y+3][x-3]==0 && chessboard->board[y-1][x+1]==0))
            ) { score[i][m] += (4 + bias); }

            // SPECIAL. ( V-Shaped )
            if ( (x>=3 && x<=w-2 && y<=h-2) && (chessboard->board[y+1][x-1]==k[m] && chessboard->board[y+2][x-2]==k[m] && chessboard->board[y+1][x+1]==k[m] && chessboard->board[y+2][x+2]==k[m])
            ) { score[i][m] += (12 + 3 * bias); }

            // CHESS PIECES COUNT.
            int pce = 0;
            if ((x>=2) && (chessboard->board[y][x-1]==k[m])) { pce++; }
            if ((x>=2 && y>=2) && (chessboard->board[y-1][x-1]==k[m])) { pce++; }
            if ((x<=w-1) && (chessboard->board[y][x+1]==k[m])) { pce++; }
            if ((x<=w-1 && y>=2) && (chessboard->board[y-1][x+1]==k[m])) { pce++; }
            if ((x>=2 && y<=h-1) && (chessboard->board[y+1][x-1]==k[m])) { pce++; }
            if ((y<=h-1) && (chessboard->board[y+1][x]==k[m])) { pce+=2; }
            if ((x<=w-1 && y<=h-1) && (chessboard->board[y+1][x+1]==k[m])) { pce++; }
            score[i][m] += pce;
        }
    }

    /* Eva 2: the next step. */
    int danger[MAX_WIDTH] = {0};
    for ( int i=1; i<=w; i++ ) {
        int x = i, y = h-chessboard->colSize[i];
        if ( y <= 0 ) { continue; }
        // POTENTIAL SINGLE 4.
        if ( y>=2 && JudgeLine_mtw(x, y-1, OPPO, h, w, NewBoard) ) { score[i][0] -= 800; score[i][1] -= 800; danger[x] = 1; }
        // POTENTIAL L3.
        if ( y>=2 && JudgeL3_mtw(x, y-1, OPPO, h, w, NewBoard) ) { score[i][0] -= 150; score[i][1] -= 150; danger[x] = 1; }
        // POTENTIAL MULTIPLE D3.
        if ( y>=2 && CountD3_mtw(x, y-1, OPPO, h, w, NewBoard)>=2 ) { score[i][0] -= 150; score[i][1] -= 150; danger[x] = 1; }
    }
    for ( int i=1; i<=w; i++ ) {
        int x1 = i, y1 = h-chessboard->colSize[i];
        if ( danger[i] ) {
            NewBoard[y1][x1] = OPPO;
            for ( int j=1; j<=w; j++ ) {
                int x2 = j, y2 = h-chessboard->colSize[j];
                if ( j!=i && JudgeLine_mtw(x2, y2, OPPO, h, w, NewBoard)) {
                    score[j][0] += 50; score[j][1] += 50;
                }
            }
            NewBoard[y1][x1] = 0;
        }
    }

    // Getting the highest score.
    int max_score = 0, next_pos = rand() % 3 + w/2;
    for ( int i = 1; i <= w; i++ ) {
        for ( int j = 0; j <= 1; j++ ) {
            if ( score[i][j] > max_score ) {
                max_score = score[i][j];
                next_pos = i;
            }
        }
    }
    return next_pos;
}

int main() {
    Chessboard cb;
    Chessboard* chessBoard = &cb;
    InitBoard(&HL, 16, 16);
    InitBoard(chessBoard, 16, 16);
    int pos = 0;
    while ( 1 ) {
        // computer
        PutChess(chessBoard, Player_mtw(chessBoard), GetColor_mtw(chessBoard));
        if ( IsFinished_mtw(chessBoard) ) {
            Draw(chessBoard, Player_mtw(chessBoard));
            printf("\n=======================================\n");
            printf("                YOU LOST!\n");
            printf("=======================================\n");
            break; 
        }
        Draw(chessBoard, Player_mtw(chessBoard));
        // player
        scanf("%d", &pos);
        PutChess(chessBoard, pos, YELLOW);
        if ( IsFinished_mtw(chessBoard) ) {
            Draw(chessBoard, pos);
            printf("\n=======================================\n");
            printf("                YOU WON!\n");
            printf("=======================================\n");
            break; 
        }
        Draw(chessBoard, pos);
    }
    Sleep(30000);
    return 0;
}