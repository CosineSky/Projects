/*************************************
* @author: CosSky
* @date: 2022/12/13
* @version: 0.5
**************************************/

#include <time.h>
#include <stdio.h>
#include <stdbool.h>
#include <windows.h>

#define SLOTS 10
#define CARD_SET 13
#define TOTAL_CARDS 104
#define red_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
#define gray_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
#define aqua_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 11);
#define green_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
#define white_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
#define yellow_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 6);
#define bright_ SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
#define color_ if(id/14==0){bright_}if(id/14==1){red_}if(id/14==2){aqua_}if(id/14==3){yellow_}if(highlight){green_}

bool quit = 0;
bool failed = 0;
bool game_running = 0;
bool regret_chance = 0;

int output, hint;
int srch, desh, cnth;
int src_, des_, cnt_, open_;
int deals = 5, collected = 0, color_sets[8];
char start, last_req, req[114514], bucket[14];

typedef struct {
    int heap[5], hidden[5], revealed[99];
    int max_sucessive[CARD_SET];
    int amount_heap, amount_hidden, amount_revealed;
    int movable, ms_low, ms_high;
} Slot; Slot slots[SLOTS];

/*******************************************************************/

int Max(int a, int b) { return a>b ? a:b; }
int Min(int a, int b) { return a<b ? a:b; }
void Swap(int* a, int* b) { int t = *a; *a = *b; *b = t; }

void Shuffle(int *arr, int len) {
    srand(time(NULL));
    for ( int i=0; i<len; i++ ) {
        int tmp1 = (rand() % len), tmp2 = (rand() % len);
        if ( tmp1 != tmp2 ) { Swap(&arr[tmp1], &arr[tmp2]); }
    }
}

int GetMaxCards() {
    int ret = 0;
    for ( int i=0; i<SLOTS; i++ ) {
        ret = Max(ret, (slots[i].amount_hidden+slots[i].amount_revealed));
    }
    return ret;
}

void DrawCardBoard() {
    system("cls");
    aqua_ printf("\n>> CosSky's Spider Solitaire v0.4 <<");
    white_ printf("\n====================================================================================================\n\n");

    printf("Deals: %d                                  Collected: %d\n", deals, collected);
    if ( deals || collected ) {
        // line 1
        for ( int i=0; i<deals; i++ ) { printf("%c", 218); }
        if ( deals ) { printf("-%c", 191); } else { printf("  "); } printf("                                   ");
        for ( int i=0; i<5-deals; i++ ) { printf(" "); }
        for ( int i=0; i<collected; i++ ) { printf("%c-%c ", 218, 191); }
        printf("\n");

        // line 2
        for ( int i=0; i<deals; i++ ) { printf("|"); }
        if ( deals ) {
            gray_ printf("?"); white_ printf("|");
        } else { printf("  "); } printf("                                   ");
        for ( int i=0; i<5-deals; i++ ) { printf(" "); }
        for ( int i=0; i<collected; i++ ) {
            printf("|");
            switch ( color_sets[i] ) {
                case 0: bright_ break;
                case 1: red_ break;
                case 2: aqua_ break;
                case 3: yellow_ break;
            } printf("A");
            white_ printf("| ");
        }
        printf("\n");

        // lines 3
        for ( int i=0; i<deals; i++ ) { printf("%c", 192); }
        if ( deals ) { printf("-%c", 217); } else { printf("  "); } printf("                                   ");
        for ( int i=0; i<5-deals; i++ ) { printf(" "); }
        for ( int i=0; i<collected; i++ ) { printf("%c-%c ", 192, 217); }
        printf("\n");
    }
    printf("\n====================================================================================================\n\n");
    for ( int i=1; i<=SLOTS; i++ ) { printf(" %d  ", i); }
    printf("\n");
    
    // Decide whether the drawing of a specific slot is finished.
    int end_draw[SLOTS] = {0};

    for ( int i=0; i<Max(1+2*GetMaxCards(), 11); i++ ) {
        white_
        for ( int j=0; j<SLOTS; j++ ) {
            
            // Just finished, draw the lower part of a card.
            if ( !(i%2) && (i/2) == slots[j].amount_hidden + slots[j].amount_revealed ) {
                if ( i ) { printf("%c-%c ", 192, 217); } else { printf("*** "); }
                end_draw[j] = 1;
                continue;
            }
            // Not finished, draw the upper part.
            if ( !(i%2) ) { 
                if ( !end_draw[j] ) { printf("%c-%c ", 218, 191); } else { printf("    "); }
            } 

            // Draw the middle part.
            else {
                if ( end_draw[j] ) { printf("    "); } else {
                    if ( (i/2) < slots[j].amount_hidden ) {
                        printf("|"); gray_ printf("?"); white_ printf("| ");
                    }
                    if ( (i/2) >= slots[j].amount_hidden && (i/2) < slots[j].amount_hidden + slots[j].amount_revealed ) {
                        // Decide whether a full pack of cards will be eliminated.
                        int highlight = 0;
                        if ( slots[j].max_sucessive[12]%14 == 13 && (i/2) >= slots[j].amount_hidden + slots[j].amount_revealed - 13 ) {
                            highlight = 1;
                        }
                        
                        int id = slots[j].revealed[(i/2)-slots[j].amount_hidden];
                        switch ( id % 14 ) {
                            case 1:
                                printf("|"); color_ printf("A"); white_ printf("| "); break;
                            case 10:
                                printf("|"); color_ printf("0"); white_ printf("| "); break;
                            case 11:
                                printf("|"); color_ printf("J"); white_ printf("| "); break;
                            case 12:
                                printf("|"); color_ printf("Q"); white_ printf("| "); break;
                            case 13:
                                printf("|"); color_ printf("K"); white_ printf("| "); break;
                            default:
                                printf("|");
                                color_ printf("%d", slots[j].revealed[(i/2)-slots[j].amount_hidden]%14);
                                white_ printf("| ");
                                break;
                        }
                    }
                }
            }
        }

        // Draw the sidebar.
        switch ( i ) {
            case 0: { aqua_ printf("  Operations:"); break; }
            case 1: { printf("  M <x> <y> <a>:  Move <a> cards from column <x> to <y>."); break; }
            case 2: { printf("  D:              Deal a pack of cards to the board."); break; }
            case 3: { printf("  U:              Undo your last operation."); break; }
            case 4: { printf("  H:              Get some hints."); break; }
            case 5: { printf("  R <1|2|4>:      Restart the game. (1=Easy 2=Medium 4=Hard)"); break; }
            case 6: { printf("  Q:              Quit the game."); break; }
            case 8: { aqua_ printf("  Message Box:"); break; }
            case 9: {
                switch ( output ) {
                    case 0: { printf("  >> Good luck!"); break; }
                    case 1: { printf("  >> No more cards to deal! :("); break; }
                    case 2: { printf("  >> A new set of cards dealt!"); break; }
                    case 3: { printf("  >> You can't move so many cards! :("); break; }
                    case 4: { printf("  >> You can't move cards there! :("); break; }
                    case 5: { printf("  >> You can't regret anymore! :("); break; }
                    case 6: { printf("  >> Invalid column! :("); break; }
                    case 7: { printf("  >> Successfully moved %d card(s) from column %d to %d!", cnt_, src_, des_); break; }
                    case 8: { printf("  >> Hint: Deal cards."); break; }
                    case 9: { printf("  >> Hint: Move %d card(s) from column %d to %d!", cnth, srch+1, desh+1); break; }
                    case 10: { printf("  >> Are you sure to quit? (Input Q again)"); break; }
                    case 11: { printf("  >> Started a new game! (Easy mode)"); break; }
                    case 12: { printf("  >> Started a new game! (Medium mode)"); break; }
                    case 13: { printf("  >> Started a new game! (Hard mode)"); break; }
                    case 14: { printf("  >> ......"); break; }
                    case 15: { printf("  >> Invalid game mode! :("); break; }
                    case 16: { printf("  >> No more hints! :("); break; }
                    case 17: { printf("  >> Revoked your last moving operation!"); break; }
                    case 18: { printf("  >> Revoked your last card-dealing operation!"); break; }
                    case 19: { printf("  >> Unable to undo your last operation! :("); break; }
                    case 20: { printf("  >> You can't deal cards when there're empty columns! :("); break; }
                    case 21: { green_ printf("  >> Congratulations! You won! :D"); break; }
                } break;
            }
            case 10: { if ( game_running && failed ) { printf("  >> It seems you're unable to win the game. Maybe restart?"); } }
        }
        printf("\n");
    }
    printf("\n====================================================================================================\n");
    if ( game_running ) { printf(">> Input your operation here: "); }
}

void RevealHiddenCards() {
    open_ = ( req[0] == 'M' ) ? 0:open_;
    for ( int i=0; i<SLOTS; i++ ) {
        if ( !slots[i].amount_revealed && slots[i].amount_hidden ) {
            slots[i].revealed[0] = slots[i].hidden[slots[i].amount_hidden-1];
            slots[i].amount_revealed++;
            slots[i].amount_hidden--;
            open_ = 1;
        }
    }
}

void GetMaxSuccessive() {
    for ( int i=0; i<SLOTS; i++ ) {
        for ( int j=0; j<CARD_SET; j++ ) { slots[i].max_sucessive[j] = 0; }
        int idx = 0;
        for ( int j=slots[i].amount_revealed; j>0; j-- ) {
            // Not first card.
            if ( idx ) {
                if ( (slots[i].max_sucessive[idx-1] == slots[i].revealed[j-1] - 1 ) ) {
                    slots[i].max_sucessive[idx] = slots[i].revealed[j-1]; idx++;
                } else { break; }
            }
            // First card.
            else { slots[i].max_sucessive[idx] = slots[i].revealed[j-1]; idx++; }   
        }
        // Update movable cards.
        slots[i].movable = idx;
        slots[i].ms_low = slots[i].max_sucessive[0];
        slots[i].ms_high = slots[i].max_sucessive[idx-1];
    }
}

void EliminateCards() {
    for ( int i=0; i<SLOTS; i++ ) {
        int first = slots[i].max_sucessive[0];
        int color = first / 14;
        int removable = 1;
        if ( first % 14 != 1 ) { removable = 0; }
        else {
            for ( int j=0; j<CARD_SET; j++ ) {
                if ( slots[i].max_sucessive[j] != j+1+14*color ) {
                    removable = 0;
                    break;
                }
            }
        }
        if ( removable ) {
            DrawCardBoard();
            Sleep(200);
            for ( int j=0; j<CARD_SET; j++ ) {
                slots[i].amount_revealed--;
                DrawCardBoard();
                Sleep(50);
            }
            color_sets[collected] = color;
            collected++;
        }
    }
}

void Init(int mode) {
    int pool_idx = 0;
    int card_pool[TOTAL_CARDS] = {
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
    };
    if ( mode == 2 ) {
        for ( int i=0; i<4; i++ ) {
            for ( int j=0; j<CARD_SET; j++ ) {
                card_pool[(4+i)*CARD_SET+j] = 15 + j;
            }
        }
    } else if ( mode == 4 ) {
        for ( int k=0; k<3; k++ ) {
            for ( int i=0; i<2; i++ ) {
                for ( int j=0; j<CARD_SET; j++ ) {
                    card_pool[(2*(k+1)+i)*CARD_SET+j] = 15 + 14 * k + j;
                }
            }
        }
    }
    Shuffle(card_pool, TOTAL_CARDS);
    for ( int i=0; i<SLOTS; i++ ) {
        slots[i].amount_heap = 5;
        slots[i].amount_revealed = 1;
        slots[i].amount_hidden = ( i<4 ? 5:4 );
        slots[i].revealed[0] = card_pool[pool_idx++];
        for ( int j=0; j<5; j++ ) {
            slots[i].heap[j] = card_pool[pool_idx++];
        }
        for ( int j=0; j<slots[i].amount_hidden; j++ ) {
            slots[i].hidden[j] = card_pool[pool_idx++];
        }
    }
    deals = 5;
    failed = 0;
    collected = 0;
    game_running = 1;
}

void JudgeWin() { game_running = !( collected == 8 ); }
void JudgeFail() {
    for ( int i=0; i<14; i++ ) { bucket[i] = 0; }
    if ( !deals ) {
        for ( int i=0; i<SLOTS; i++ ) {
            int j = 0;
            while ( slots[i].max_sucessive[j] != 0 ) {
                bucket[slots[i].max_sucessive[j]%14]++;
                j++;
            }
        }
        for ( int i=1; i<=CARD_SET; i++ ) {
            if ( !bucket[i] ) { failed = 1; }
        }
    }
}

void Update() {
    GetMaxSuccessive();
    EliminateCards();
    RevealHiddenCards();
    GetMaxSuccessive();
    JudgeFail();
    JudgeWin();
    DrawCardBoard();
}

/*******************************************************************/

void DealCards() {
    for ( int i=0; i<SLOTS; i++ ) {
        if ( !slots[i].amount_revealed && !slots[i].amount_hidden ) {
            output = 20; return;
        }
    }
    if ( !deals ) { output = 1; }
    else {
        for ( int i=0; i<SLOTS; i++ ) {
            slots[i].amount_revealed++;
            slots[i].revealed[slots[i].amount_revealed-1] = slots[i].heap[slots[i].amount_heap-1];
            slots[i].amount_heap--;
            DrawCardBoard();
            Sleep(50);
        }
        regret_chance = 1; deals--; output = 2;
    }
}

void MoveCards(int src, int des, int cnt) {
    if ( cnt > slots[src].movable ) { output = 3; }
    else {
        if ( (slots[des].revealed[slots[des].amount_revealed-1]%14 != slots[src].revealed[slots[src].amount_revealed-cnt]%14 + 1) &&
            ( (slots[des].amount_revealed + slots[des].amount_hidden) ) ) {
            output = 4;
        } else {
            for ( int i=0; i<cnt; i++ ) {
                slots[des].revealed[slots[des].amount_revealed+i] = slots[src].revealed[slots[src].amount_revealed-cnt+i];
            }
            slots[src].amount_revealed -= cnt;
            slots[des].amount_revealed += cnt;
            regret_chance = 1;
        }
    }
}

void Regret() {
    if ( !regret_chance ) { output = 5; }
    else {
        switch ( last_req ) {
            case 'M': {
                if ( open_ ) {
                    slots[src_-1].hidden[slots[src_-1].amount_hidden] = slots[src_-1].revealed[0];
                    slots[src_-1].amount_hidden++;
                    slots[src_-1].amount_revealed--;
                }
                for ( int i=0; i<cnt_; i++ ) {
                    slots[src_-1].revealed[slots[src_-1].amount_revealed+i] = slots[des_-1].revealed[slots[des_-1].amount_revealed-cnt_+i];
                }
                slots[des_-1].amount_revealed -= cnt_;
                slots[src_-1].amount_revealed += cnt_;
                regret_chance = 0; output = 17;
                break;
            }
            case 'D': {
                for ( int i=0; i<SLOTS; i++ ) {
                    slots[i].heap[slots[i].amount_heap] = slots[i].revealed[slots[i].amount_revealed-1];
                    slots[i].amount_heap++;
                    slots[i].amount_revealed--;
                }
                regret_chance = 0; output = 18; deals++;
                break;
            }
            default: output = 19;
        }
    }
}

void GetHint() {
    int hint = 1, priority = 0;
    for ( int src=0; src<SLOTS; src++ ) {
        if ( !slots[src].amount_revealed ) { continue; }
        for ( int des=0; des<SLOTS; des++ ) {
            if ( src != des ) {
                if ( slots[des].ms_high%14 == 13 && slots[des].ms_high-slots[src].ms_low == 12 &&
                    slots[src].ms_high%14 >= slots[des].ms_low%14-1 ) {
                    priority = 1; srch = src; desh = des;
                    cnth = slots[des].ms_low%14-1;
                    goto finished;
                }
                if ( slots[src].ms_high == slots[des].ms_low - 1 && !priority) {
                    priority = 1; srch = src; desh = des;
                    cnth = slots[src].movable;
                    goto finished;
                }
            }
        }
    }
    finished:
    output = priority + 8;
    if ( !deals && output == 8 ) { output = 16; }
}

/*******************************************************************/

int main() {
    SetConsoleOutputCP(437);

    while ( !game_running ) {
        system("cls");
        aqua_ printf("\n>> CosSky's Spider Solitaire v0.4 <<\n");
        white_ printf("=======================================\nInput:\n");
        printf("\"1\" to start a game with one color.\n");
        printf("\"2\" to start a game with two colors.\n");
        printf("\"4\" to start a game with four colors.\n");
        printf("\n>> Input your operation here: ");
        scanf("%c", &start);
        if ( start == '1' ) { Init(1); }
        else if ( start == '2' ) { Init(2); }
        else if ( start == '4' ) { Init(4); }
    }

    game:
    while ( game_running ) {
        Update();
        if ( !game_running ) { goto game; }
        output = 14; hint = 0;
        scanf("%s", req);
        if ( req[0] == 'Q' ) {
            output = 10;
            DrawCardBoard();
            scanf("%s", req);
            if ( req[0] == 'Q' ) { exit(0); }
        }
        if ( req[0] == 'R' ) {
            getchar(); scanf("%c", &start);
            if ( start == '1' ) {  output = 11; Init(1); goto game; }
            else if ( start == '2' ) { output = 12; Init(2); goto game; }
            else if ( start == '4' ) { output = 13; Init(4); goto game; }
            else { output = 15; }
        }
        if ( req[0] == 'H' ) { GetHint(); }
        if ( req[0] == 'D' ) { DealCards(); }
        if ( req[0] == 'U' ) { Regret(); }
        if ( req[0] == 'M' ) {
            scanf("%d %d %d", &src_, &des_, &cnt_);
            if ( src_ >= 1 && src_ <= 10 && des_ >= 1 && des_ <= 10 ) {
                output = 7;
                MoveCards(src_-1, des_-1, cnt_);
            } else { output = 6; }
        }
        if ( req[0] == 'M' || req[0] == 'D' ) { last_req = req[0]; }
    }

    while ( !game_running && collected == 8 ) {
        output = 21;
        Update();
        white_ printf("Now input:\n\"1\" to start another game with one color.\n");
        printf("\"2\" to start another game with two colors.\n");
        printf("\"4\" to start another game with four colors.\n");
        printf("If you want to quit, input \"Q\".\n\n");
        printf(">> Input your operation here: ");
        scanf("%c", &start);
        if ( start == '1' ) { Init(1); goto game; }
        else if ( start == '2' ) { Init(2); goto game; }
        else if ( start == '4' ) { Init(4); goto game; }
        else if ( start == 'Q' ) { exit(0); }
        system("cls");
    }
}