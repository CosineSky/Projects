import time;
import copy;
import random;
import tkinter;

class Game:
    def __init__(self):
        self.lose = False;
        self.win = False;
        self.standard = [];
        self.clickLeftPos = [];
        self.clickRightPos = [];
        self.clickDoublePos = [];
        for i in range(len(g.field)):
            self.standard.append(str(i+1));
        tk.bind("<Button-1>",self.clickLeft);
    
    def main(self):
        fx = random.randint(6,8);
        fy = random.randint(6,8);
        g.field[fx][fy] = 2;
        canvas.create_oval(fx*40+35, fy*40+35, fx*40+65, fy*40+65, fill="white");
        while self.lose == False and self.win == False:
            canvas.update();
            if self.clickLeftPos != []:
                self.step();
                self.check_win();
        if self.win == True:
            print("\n======Congratulations! You Won!======\n");
        if self.lose == True:
            print("\n======You lost! Get Good!======\n");

    def step(self):
        if g.field[self.x][self.y] == 0:
            g.field[self.x][self.y] = 1;
            canvas.create_oval(self.x*40+35, self.y*40+35, self.x*40+65, self.y*40+65, fill="black");
            self.computer();

    def check_win(self):
        for i in range(len(g.field)):
            for j in range(len(g.field)):
                if i >= 2 and i <= len(g.field)-3:
                    if g.field[i-2][j] == 1 and g.field[i-1][j] == 1 and g.field[i][j] == 1 and g.field[i+1][j] == 1 and g.field[i+2][j] == 1: self.win=True;
                    if g.field[i-2][j] == 2 and g.field[i-1][j] == 2 and g.field[i][j] == 2 and g.field[i+1][j] == 2 and g.field[i+2][j] == 2: self.lose=True;
                if j >= 2 and j <= len(g.field)-3:
                    if g.field[i][j-2] == 1 and g.field[i][j-1] == 1 and g.field[i][j] == 1 and g.field[i][j+1] == 1 and g.field[i][j+2] == 1: self.win=True;
                    if g.field[i][j-2] == 2 and g.field[i][j-1] == 2 and g.field[i][j] == 2 and g.field[i][j+1] == 2 and g.field[i][j+2] == 2: self.lose=True;
                if i >= 2 and i <= len(g.field)-3 and j >= 2 and j <= len(g.field)-3:
                    if g.field[i-2][j-2] == 1 and g.field[i-1][j-1] == 1 and g.field[i][j] == 1 and g.field[i+1][j+1] == 1 and g.field[i+2][j+2] == 1: self.win=True;
                    if g.field[i-2][j-2] == 2 and g.field[i-1][j-1] == 2 and g.field[i][j] == 2 and g.field[i+1][j+1] == 2 and g.field[i+2][j+2] == 2: self.lose=True;
                    if g.field[i-2][j+2] == 1 and g.field[i-1][j+1] == 1 and g.field[i][j] == 1 and g.field[i+1][j-1] == 1 and g.field[i+2][j-2] == 1: self.win=True;
                    if g.field[i-2][j+2] == 2 and g.field[i-1][j+1] == 2 and g.field[i][j] == 2 and g.field[i+1][j-1] == 2 and g.field[i+2][j-2] == 2: self.lose=True;
                    
    def computer(self):
        current_max = 0;
        temp = copy.deepcopy(empty);
        threes = copy.deepcopy(empty);
        for i in range(15):
            for j in range(15):
                if g.field[i][j] != 0:
                    temp[i][j] = -1;
                if g.field[i][j] == 0:
                    for k in (1,2):
                        d = 0.000001 * (k-1);
                        #k represents the computer's strategy ( 1=defensive, 2=offensive )
                        #The existence of d gives the computer preference to offense.
                        #5-1.
                        if i >= 4:
                            if g.field[i-1][j] == k and g.field[i-2][j] == k and g.field[i-3][j] == k and g.field[i-4][j] == k: temp[i][j] += 10+1000000*d;
                        if i <= len(g.field)-5:
                            if g.field[i+1][j] == k and g.field[i+2][j] == k and g.field[i+3][j] == k and g.field[i+4][j] == k: temp[i][j] += 10+1000000*d;
                        if j >= 4:
                            if g.field[i][j-1] == k and g.field[i][j-2] == k and g.field[i][j-3] == k and g.field[i][j-4] == k: temp[i][j] += 10+1000000*d;
                        if j <= len(g.field)-5:
                            if g.field[i][j+1] == k and g.field[i][j+2] == k and g.field[i][j+3] == k and g.field[i][j+4] == k: temp[i][j] += 10+1000000*d;
                        if i >= 4 and j >= 4:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == k and g.field[i-3][j-3] == k and g.field[i-4][j-4] == k: temp[i][j] += 10+1000000*d;
                        if i <= len(g.field)-5 and j <= len(g.field)-5:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == k and g.field[i+3][j+3] == k and g.field[i+4][j+4] == k: temp[i][j] += 10+1000000*d;
                        if i >= 4 and j <= len(g.field)-5:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == k and g.field[i-3][j+3] == k and g.field[i-4][j+4] == k: temp[i][j] += 10+1000000*d;
                        if j >= 4 and i <= len(g.field)-5:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == k and g.field[i+3][j-3] == k and g.field[i+4][j-4] == k: temp[i][j] += 10+1000000*d;
                        #5-2.
                        if i >= 3 and i <= len(g.field)-2:
                            if g.field[i-1][j] == k and g.field[i-2][j] == k and g.field[i-3][j] == k and g.field[i+1][j] == k: temp[i][j] += 10+1000000*d;
                        if i <= len(g.field)-4 and i >= 1:
                            if g.field[i+1][j] == k and g.field[i+2][j] == k and g.field[i+3][j] == k and g.field[i-1][j] == k: temp[i][j] += 10+1000000*d;
                        if j >= 3 and j <= len(g.field)-2:
                            if g.field[i][j-1] == k and g.field[i][j-2] == k and g.field[i][j-3] == k and g.field[i][j+1] == k: temp[i][j] += 10+1000000*d;
                        if j <= len(g.field)-4 and j >= 1:
                            if g.field[i][j+1] == k and g.field[i][j+2] == k and g.field[i][j+3] == k and g.field[i][j-1] == k: temp[i][j] += 10+1000000*d;
                        if i >= 3 and i <= len(g.field)-2 and j >= 3 and j <= len(g.field)-2:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == k and g.field[i-3][j-3] == k and g.field[i+1][j+1] == k: temp[i][j] += 10+1000000*d;
                        if i <= len(g.field)-4 and i >= 1 and j <= len(g.field)-4 and j >= 1:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == k and g.field[i+3][j+3] == k and g.field[i-1][j-1] == k: temp[i][j] += 10+1000000*d;
                        if i >= 3 and i <= len(g.field)-2 and j <= len(g.field)-4 and j >= 1:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == k and g.field[i-3][j+3] == k and g.field[i+1][j-1] == k: temp[i][j] += 10+1000000*d;
                        if i <= len(g.field)-4 and i >= 1 and j >= 3 and j <= len(g.field)-2:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == k and g.field[i+3][j-3] == k and g.field[i-1][j+1] == k: temp[i][j] += 10+1000000*d;
                        #5-3.
                        if i >= 2 and i <= len(g.field)-3:
                            if g.field[i-2][j] == k and g.field[i-1][j] == k and g.field[i+1][j] == k and g.field[i+2][j] == k: temp[i][j] += 10+1000000*d;
                        if j >= 2 and j <= len(g.field)-3:
                            if g.field[i][j-2] == k and g.field[i][j-1] == k and g.field[i][j+1] == k and g.field[i][j+2] == k: temp[i][j] += 10+1000000*d;
                        if i >= 2 and i <= len(g.field)-3 and j <= len(g.field)-3 and j >= 2:
                            if (g.field[i-2][j-2] == k and g.field[i-1][j-1] == k and g.field[i+1][j+1] == k and g.field[i+2][j+2] == k)\
                            or (g.field[i-2][j+2] == k and g.field[i-1][j+1] == k and g.field[i+1][j-1] == k and g.field[i+2][j-2] == k): temp[i][j] += 10+1000000*d;
                        #4-1.
                        if i >= 4 and i <= len(g.field)-2:
                            if g.field[i-1][j] == k and g.field[i-2][j] == k and g.field[i-3][j] == k:
                                if g.field[i-4][j] == 0 and g.field[i+1][j] == 0: temp[i][j] += 1+d;
                                elif g.field[i-4][j] == 3-k and g.field[i+1][j] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i-4][j] == 0 and g.field[i+1][j] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 1 and i <= len(g.field)-5:
                            if g.field[i+1][j] == k and g.field[i+2][j] == k and g.field[i+3][j] == k:
                                if g.field[i+4][j] == 0 and g.field[i-1][j] == 0: temp[i][j] += 1+d;
                                elif g.field[i+4][j] == 3-k and g.field[i-1][j] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i+4][j] == 0 and g.field[i-1][j] == 3-k: temp[i][j] += 0.05+d;
                        if j >= 4 and j <= len(g.field)-2:
                            if g.field[i][j-1] == k and g.field[i][j-2] == k and g.field[i][j-3] == k:
                                if g.field[i][j-4] == 0 and g.field[i][j+1] == 0: temp[i][j] += 1+d;
                                elif g.field[i][j-4] == 3-k and g.field[i][j+1] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i][j-4] == 0 and g.field[i][j+1] == 3-k: temp[i][j] += 0.05+d;
                        if j >= 1 and j <= len(g.field)-5:
                            if g.field[i][j+1] == k and g.field[i][j+2] == k and g.field[i][j+3] == k:
                                if g.field[i][j+4] == 0 and g.field[i][j-1] == 0: temp[i][j] += 1+d;
                                elif g.field[i][j+4] == 3-k and g.field[i][j-1] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i][j+4] == 0 and g.field[i][j-1] == 3-k: temp[i][j] += 0.05+d;
                                
                        if i >= 4 and i <= len(g.field)-2 and j >= 4 and j <= len(g.field)-2:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == k and g.field[i-3][j-3] == k:
                                if g.field[i-4][j-4] == 0 and g.field[i+1][j+1] == 0: temp[i][j] += 1+d;
                                elif g.field[i-4][j-4] == 3-k and g.field[i+1][j+1] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i-4][j-4] == 0 and g.field[i+1][j+1] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 4 and i <= len(g.field)-2 and j >= 1 and j <= len(g.field)-5:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == k and g.field[i-3][j+3] == k:
                                if g.field[i-4][j+4] == 0 and g.field[i+1][j-1] == 0: temp[i][j] += 1+d;
                                elif g.field[i-4][j+4] == 3-k and g.field[i+1][j-1] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i-4][j+4] == 0 and g.field[i+1][j-1] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 1 and i <= len(g.field)-5 and j >= 4 and j <= len(g.field)-2:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == k and g.field[i+3][j-3] == k:
                                if g.field[i+4][j-4] == 0 and g.field[i-1][j+1] == 0: temp[i][j] += 1+d;
                                elif g.field[i+4][j-4] == 3-k and g.field[i-1][j+1] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i+4][j-4] == 0 and g.field[i-1][j+1] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 1 and i <= len(g.field)-5 and j >= 1 and j <= len(g.field)-5:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == k and g.field[i+3][j+3] == k:
                                if g.field[i+4][j+4] == 0 and g.field[i-1][j-1] == 0: temp[i][j] += 1+d;
                                elif g.field[i+4][j+4] == 3-k and g.field[i-1][j-1] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i+4][j+4] == 0 and g.field[i-1][j-1] == 3-k: temp[i][j] += 0.05+d;
                        #4-2.
                        if i >= 3 and i <= len(g.field)-3:
                            if g.field[i-1][j] == k and g.field[i-2][j] == k and g.field[i+1][j] == k:
                                if g.field[i-3][j] == 0 and g.field[i+2][j] == 0: temp[i][j] += 1+d;
                                elif g.field[i-3][j] == 3-k and g.field[i+2][j] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i-3][j] == 0 and g.field[i+2][j] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 2 and i <= len(g.field)-4:
                            if g.field[i+1][j] == k and g.field[i+2][j] == k and g.field[i-1][j] == k:
                                if g.field[i+3][j] == 0 and g.field[i-2][j] == 0: temp[i][j] += 1+d;
                                elif g.field[i+3][j] == 3-k and g.field[i-2][j] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i+3][j] == 0 and g.field[i-2][j] == 3-k: temp[i][j] += 0.05+d;
                        if j >= 3 and j <= len(g.field)-3:
                            if g.field[i][j-1] == k and g.field[i][j-2] == k and g.field[i][j+1] == k:
                                if g.field[i][j-3] == 0 and g.field[i][j+2] == 0: temp[i][j] += 1+d;
                                elif g.field[i][j-3] == 3-k and g.field[i][j+2] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i][j-3] == 0 and g.field[i][j+2] == 3-k: temp[i][j] += 0.05+d;
                        if j >= 2 and j <= len(g.field)-4:
                            if g.field[i][j+1] == k and g.field[i][j+2] == k and g.field[i][j-1] == k:
                                if g.field[i][j+3] == 0 and g.field[i][j-2] == 0: temp[i][j] += 1+d;
                                elif g.field[i][j+3] == 3-k and g.field[i][j-2] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i][j+3] == 0 and g.field[i][j-2] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == k and g.field[i+1][j+1] == k:
                                if g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 0: temp[i][j] += 1+d;
                                elif g.field[i-3][j-3] == 3-k and g.field[i+2][j+2] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == k and g.field[i+1][j-1] == k:
                                if g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 0: temp[i][j] += 1+d;
                                elif g.field[i-3][j+3] == 3-k and g.field[i+2][j-2] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == k and g.field[i-1][j+1] == k:
                                if g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 0: temp[i][j] += 1+d;
                                elif g.field[i+3][j-3] == 3-k and g.field[i-2][j+2] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 3-k: temp[i][j] += 0.05+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == k and g.field[i-1][j-1] == k:
                                if g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 0: temp[i][j] += 1+d;
                                elif g.field[i+3][j+3] == 3-k and g.field[i-2][j-2] == 0: temp[i][j] += 0.05+d;
                                elif g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 3-k: temp[i][j] += 0.05+d;
                        #3-1.                      
                        if i >= 3 and i <= len(g.field)-3:
                            if g.field[i-1][j] == k and g.field[i-2][j] == k and g.field[i+1][j] == 0:
                                if g.field[i-3][j] == 0 and g.field[i+2][j] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i-3][j] == 3-k and g.field[i+2][j] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i-3][j] == 0 and g.field[i+2][j] == 3-k: temp[i][j] += 0.02+d;
                        if i >= 2 and i <= len(g.field)-4:
                            if g.field[i+1][j] == k and g.field[i+2][j] == k and g.field[i-1][j] == 0:
                                if g.field[i+3][j] == 0 and g.field[i-2][j] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i+3][j] == 3-k and g.field[i-2][j] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i+3][j] == 0 and g.field[i-2][j] == 3-k: temp[i][j] += 0.02+d;
                        if j >= 3 and j <= len(g.field)-3:
                            if g.field[i][j-1] == k and g.field[i][j-2] == k and g.field[i][j+1] == 0:
                                if g.field[i][j-3] == 0 and g.field[i][j+2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i][j-3] == 3-k and g.field[i][j+2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i][j-3] == 0 and g.field[i][j+2] == 3-k: temp[i][j] += 0.02+d;
                        if j >= 2 and j <= len(g.field)-4:
                            if g.field[i][j+1] == k and g.field[i][j+2] == k and g.field[i][j-1] == 0:
                                if g.field[i][j+3] == 0 and g.field[i][j-2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i][j+3] == 3-k and g.field[i][j-2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i][j+3] == 0 and g.field[i][j-2] == 3-k: temp[i][j] += 0.02+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == k and g.field[i+1][j+1] == 0:
                                if g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i-3][j-3] == 3-k and g.field[i+2][j+2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 3-k: temp[i][j] += 0.02+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == k and g.field[i+1][j-1] == 0:
                                if g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i-3][j+3] == 3-k and g.field[i+2][j-2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 3-k: temp[i][j] += 0.02+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == k and g.field[i-1][j+1] == 0:
                                if g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i+3][j-3] == 3-k and g.field[i-2][j+2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 3-k: temp[i][j] += 0.02+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == k and g.field[i-1][j-1] == 0:
                                if g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i+3][j+3] == 3-k and g.field[i-2][j-2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 3-k: temp[i][j] += 0.02+d;
                        #3-2.
                        if i >= 3 and i <= len(g.field)-3:
                            if g.field[i-1][j] == k and g.field[i-2][j] == 0 and g.field[i+1][j] == k:
                                if g.field[i-3][j] == 0 and g.field[i+2][j] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i-3][j] == 3-k and g.field[i+2][j] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i-3][j] == 0 and g.field[i+2][j] == 3-k: temp[i][j] += 0.01+d;
                        if i >= 2 and i <= len(g.field)-4:
                            if g.field[i+1][j] == k and g.field[i+2][j] == 0 and g.field[i-1][j] == k:
                                if g.field[i+3][j] == 0 and g.field[i-2][j] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i+3][j] == 3-k and g.field[i-2][j] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i+3][j] == 0 and g.field[i-2][j] == 3-k: temp[i][j] += 0.01+d;
                        if j >= 3 and j <= len(g.field)-3:
                            if g.field[i][j-1] == k and g.field[i][j-2] == 0 and g.field[i][j+1] == k:
                                if g.field[i][j-3] == 0 and g.field[i][j+2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i][j-3] == 3-k and g.field[i][j+2] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i][j-3] == 0 and g.field[i][j+2] == 3-k: temp[i][j] += 0.01+d;
                        if j >= 2 and j <= len(g.field)-4:
                            if g.field[i][j+1] == k and g.field[i][j+2] == 0 and g.field[i][j-1] == k:
                                if g.field[i][j+3] == 0 and g.field[i][j-2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i][j+3] == 3-k and g.field[i][j-2] == 0: temp[i][j] += 0.01+d;
                                elif g.field[i][j+3] == 0 and g.field[i][j-2] == 3-k: temp[i][j] += 0.02+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == 0 and g.field[i+1][j+1] == k:
                                if g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i-3][j-3] == 3-k and g.field[i+2][j+2] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 3-k: temp[i][j] += 0.01+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == 0 and g.field[i+1][j-1] == k:
                                if g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i-3][j+3] == 3-k and g.field[i+2][j-2] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 3-k: temp[i][j] += 0.01+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == 0 and g.field[i-1][j+1] == k:
                                if g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i+3][j-3] == 3-k and g.field[i-2][j+2] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 3-k: temp[i][j] += 0.01+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == 0 and g.field[i-1][j-1] == k:
                                if g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 0: temp[i][j] += 0.08+d; threes[i][j] += 1;
                                elif g.field[i+3][j+3] == 3-k and g.field[i-2][j-2] == 0: temp[i][j] += 0.02+d;
                                elif g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 3-k: temp[i][j] += 0.01+d;
                        if threes[i][j] >= 2:
                            temp[i][j] += 0.5;
                        #2.
                        if i >= 3 and i <= len(g.field)-3:
                            if g.field[i-1][j] == k and g.field[i-2][j] == 0 and g.field[i+1][j] == 0:
                                if g.field[i-3][j] == 0 and g.field[i+2][j] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i-3][j] == 3-k and g.field[i+2][j] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i-3][j] == 0 and g.field[i+2][j] == 3-k: temp[i][j] += 0.002+d;
                        if i >= 2 and i <= len(g.field)-4:
                            if g.field[i+1][j] == k and g.field[i+2][j] == 0 and g.field[i-1][j] == 0:
                                if g.field[i+3][j] == 0 and g.field[i-2][j] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i+3][j] == 3-k and g.field[i-2][j] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i+3][j] == 0 and g.field[i-2][j] == 3-k: temp[i][j] += 0.002+d;
                        if j >= 3 and j <= len(g.field)-3:
                            if g.field[i][j-1] == k and g.field[i][j-2] == 0 and g.field[i][j+1] == 0:
                                if g.field[i][j-3] == 0 and g.field[i][j+2] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i][j-3] == 3-k and g.field[i][j+2] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i][j-3] == 0 and g.field[i][j+2] == 3-k: temp[i][j] += 0.002+d;
                        if j >= 2 and j <= len(g.field)-4:
                            if g.field[i][j+1] == k and g.field[i][j+2] == 0 and g.field[i][j-1] == 0:
                                if g.field[i][j+3] == 0 and g.field[i][j-2] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i][j+3] == 3-k and g.field[i][j-2] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i][j+3] == 0 and g.field[i][j-2] == 3-k: temp[i][j] += 0.002+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i-1][j-1] == k and g.field[i-2][j-2] == 0 and g.field[i+1][j+1] == 0:
                                if g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i-3][j-3] == 3-k and g.field[i+2][j+2] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i-3][j-3] == 0 and g.field[i+2][j+2] == 3-k: temp[i][j] += 0.002+d;
                        if i >= 3 and i <= len(g.field)-3 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i-1][j+1] == k and g.field[i-2][j+2] == 0 and g.field[i+1][j-1] == 0:
                                if g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i-3][j+3] == 3-k and g.field[i+2][j-2] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i-3][j+3] == 0 and g.field[i+2][j-2] == 3-k: temp[i][j] += 0.002+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 3 and j <= len(g.field)-3:
                            if g.field[i+1][j-1] == k and g.field[i+2][j-2] == 0 and g.field[i-1][j+1] == 0:
                                if g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i+3][j-3] == 3-k and g.field[i-2][j+2] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i+3][j-3] == 0 and g.field[i-2][j+2] == 3-k: temp[i][j] += 0.002+d;
                        if i >= 2 and i <= len(g.field)-4 and j >= 2 and j <= len(g.field)-4:
                            if g.field[i+1][j+1] == k and g.field[i+2][j+2] == 0 and g.field[i-1][j-1] == 0:
                                if g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 0: temp[i][j] += 0.005+d;
                                elif g.field[i+3][j+3] == 3-k and g.field[i-2][j-2] == 0: temp[i][j] += 0.002+d;
                                elif g.field[i+3][j+3] == 0 and g.field[i-2][j-2] == 3-k: temp[i][j] += 0.002+d;

        #Get the highest score.
        for i in range(15):
            for j in range(15):
                current_max = max(current_max, temp[i][j]);
        #Choose the spot with the highest score.
        try:
            for i in range(15):
                for j in range(15):
                    if temp[i][j] == current_max:
                        g.field[i][j] = 2;
                        canvas.create_oval(i*40+35, j*40+35, i*40+65, j*40+65, fill="white");
                        raise;
        except:
            pass;
        finally:
            pass;
    
    def clickLeft(self, event):
        self.clickLeftPos = [];
        self.clickLeftPos.append(event.x);
        self.clickLeftPos.append(event.y);
        self.x0 = self.clickLeftPos[0];
        self.y0 = self.clickLeftPos[1];
        if 30 <= self.x0 <= 630 and 30 <= self.y0 <= 630:
            self.x = int((self.x0-30) / 40);
            self.y = int((self.y0-30) / 40);
        
class Grid:
    def __init__(self):
        self.field = self.field();
        self.drawGrid();

    def field(self):
        self.field = [[0 for i in range(15)] for i in range(15)];
        return self.field;

    def drawGrid(self):
        for i in range(15):
            canvas.create_line(50, 50+40*i, 610, 50+40*i);
            canvas.create_line(50+40*i, 50, 50+40*i, 610);
            
tk = tkinter.Tk();
tk.title("Five in a Row by CosineSky");
tk.resizable(0,0);
tk.wm_attributes("-topmost", 1);
canvas = tkinter.Canvas(tk, width=660, height=660);
g = Grid();
canvas.pack();
empty = [[0 for i in range(15)] for i in range(15)];
game = Game();
game.main();
